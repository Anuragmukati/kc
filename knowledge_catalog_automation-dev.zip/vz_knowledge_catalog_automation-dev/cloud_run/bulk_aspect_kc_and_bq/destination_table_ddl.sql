-- STREAMING_CHUNK:Creating the destination BigQuery table schema for Dataplex aspects...
CREATE TABLE IF NOT EXISTS `dmgcp-del-181.VZ_KC_aspect_poc_2026_06_11.load_aspects_here` (
  source_project STRING NOT NULL OPTIONS(description="Google Cloud Project ID of the source table"),
  source_dataset STRING NOT NULL OPTIONS(description="Dataset ID of the source table"),
  source_table STRING NOT NULL OPTIONS(description="Table name of the source table"),
  dataplex_entry_name STRING OPTIONS(description="Full resource name of the Dataplex Catalog entry"),
  aspect_type STRING NOT NULL OPTIONS(description="Type/Key of the attached Dataplex Aspect"),
  aspect_data JSON OPTIONS(description="Raw payload of the attached aspect stored as native JSON"),
  create_time TIMESTAMP OPTIONS(description="Creation timestamp of the aspect in Dataplex"),
  update_time TIMESTAMP OPTIONS(description="Last update timestamp of the aspect in Dataplex"),
  extracted_at TIMESTAMP NOT NULL OPTIONS(description="Timestamp when this aspect record was extracted")
-- STREAMING_CHUNK:Configuring table partitioning and clustering options...
PARTITION BY DATE(extracted_at)
CLUSTER BY source_project, source_dataset, aspect_type
OPTIONS(
  description="Audit log table storing extracted Dataplex Catalog aspects for BigQuery tables."
);