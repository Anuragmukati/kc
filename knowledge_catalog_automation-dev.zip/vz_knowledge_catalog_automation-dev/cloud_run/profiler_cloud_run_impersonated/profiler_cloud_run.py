import csv
import hashlib
import io
import logging
import os
import re
import sys
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Optional
from zoneinfo import ZoneInfo

import google.auth
from google.api_core.exceptions import AlreadyExists, GoogleAPICallError
from google.auth import impersonated_credentials
from google.cloud import bigquery, dataplex_v1, storage


# Custom handler to force real-time log flushing in Cloud Run / GCP Cloud Logging
class FlushingStreamHandler(logging.StreamHandler):
    def emit(self, record):
        super().emit(record)
        self.flush()


# Configure Logging with Immediate Flushing
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[FlushingStreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)


DATAPLEX_SERVICE_ACCOUNT = (
    "sa-dev-jyav-dplex-dgsdo-0@vz-nonit-np-jyav-dev-dgsdo-0.iam.gserviceaccount.com"
)
DATAPLEX_HOST_PROJECT = "vz-nonit-np-jyav-dev-dgsdo-0"
EXPORT_PROJECT_ID = "vz-nonit-np-jyav-dev-dgsdo-0"
EXPORT_DATASET_ID = "gkc_governance_tbls"
EXPORT_TABLE_ID = "all_table_profiles"
CONFIG_GCS_URI = "gs://jyav-dev-dgsdo-0-usre-gkcenrichment/data_profiler_input.csv"


# Concurrency & Monitoring Configuration
MAX_WORKERS = 10               # Number of parallel table profiling workers
STATUS_INTERVAL_SECONDS = 15   # Overall progress refresh interval
JOB_TIMEOUT_SECONDS = 600      # Max wait time per table scan (10 minutes)
SDK_API_TIMEOUT = 30.0         # Max wait time for individual GCP SDK calls (30s)


def get_execution_metadata() -> dict:
    """Retrieves execution details from Cloud Run environment variables and NY timestamp."""
    ny_tz = ZoneInfo("America/New_York")
    now_ny = datetime.now(ny_tz)
    timestamp_ny = now_ny.strftime("%Y-%m-%d %H:%M:%S %Z")
    filename_timestamp = now_ny.strftime("%Y%m%d_%H%M%S")

    job_name = os.getenv("CLOUD_RUN_JOB", "Local/Manual Execution")
    execution_instance = os.getenv(
        "CLOUD_RUN_EXECUTION", os.getenv("HOSTNAME", "Local-Host-Instance")
    )

    return {
        "job_name": job_name,
        "execution_instance": execution_instance,
        "timestamp_ny": timestamp_ny,
        "filename_timestamp": filename_timestamp,
    }


@dataclass
class JobStatus:
    table_ref: str
    status: str = "PENDING"  # PENDING, RUNNING, SUCCEEDED, FAILED
    start_time: Optional[float] = None
    end_time: Optional[float] = None
    attempts: int = 0
    error_message: Optional[str] = None

    @property
    def duration(self) -> str:
        if not self.start_time:
            return "0s"
        end = self.end_time or time.time()
        elapsed = int(end - self.start_time)
        return f"{elapsed // 60}m {elapsed % 60}s" if elapsed >= 60 else f"{elapsed}s"


class StatusTracker:
    """Thread-safe tracker for running job statuses using Reentrant Lock (RLock)."""

    def __init__(self):
        self._lock = threading.RLock()
        self.jobs: Dict[str, JobStatus] = {}

    def register_job(self, table_ref: str):
        with self._lock:
            self.jobs[table_ref] = JobStatus(table_ref=table_ref)

    def update_status(self, table_ref: str, **kwargs):
        with self._lock:
            if table_ref in self.jobs:
                job = self.jobs[table_ref]
                for key, val in kwargs.items():
                    setattr(job, key, val)

    def get_summary(self) -> dict:
        with self._lock:
            total = len(self.jobs)
            succeeded = sum(1 for j in self.jobs.values() if j.status == "SUCCEEDED")
            failed = sum(1 for j in self.jobs.values() if j.status == "FAILED")
            running = sum(1 for j in self.jobs.values() if j.status == "RUNNING")
            pending = sum(1 for j in self.jobs.values() if j.status == "PENDING")
            return {
                "total": total,
                "succeeded": succeeded,
                "failed": failed,
                "running": running,
                "pending": pending,
            }

    def get_running_tables(self) -> List[str]:
        """Returns list of table references currently in RUNNING state."""
        with self._lock:
            return [t for t, j in self.jobs.items() if j.status == "RUNNING"]

    def print_final_report(self, metadata: dict) -> str:
        """Prints consolidated summary to logger and returns full text string."""
        with self._lock:
            total = len(self.jobs)
            succeeded = sum(1 for j in self.jobs.values() if j.status == "SUCCEEDED")
            failed = sum(1 for j in self.jobs.values() if j.status == "FAILED")
            running = sum(1 for j in self.jobs.values() if j.status == "RUNNING")
            pending = sum(1 for j in self.jobs.values() if j.status == "PENDING")

            lines = [
                "",
                "=" * 105,
                " " * 38 + "CONSOLIDATED EXECUTION SUMMARY",
                "=" * 105,
                f"  Cloud Run Job Name : {metadata['job_name']}",
                f"  Execution Instance : {metadata['execution_instance']}",
                f"  Timestamp (NY Time): {metadata['timestamp_ny']}",
                "=" * 105,
                f"{'TABLE REFERENCE':<45} | {'STATUS':<10} | {'DURATION':<10} | {'ATTEMPTS':<8} | {'ERROR / DETAILS'}",
                "-" * 105,
            ]

            for table_ref, job in self.jobs.items():
                err = (job.error_message or "None")[:30]
                status_str = job.status
                lines.append(
                    f"{table_ref:<45} | {status_str:<10} | {job.duration:<10} | {job.attempts:<8} | {err}"
                )

            lines.extend([
                "-" * 105,
                f"TOTAL: {total} | SUCCEEDED: {succeeded} | FAILED: {failed} | RUNNING: {running} | PENDING: {pending}",
                "=" * 105,
                ""
            ])

            report_text = "\n".join(lines)
            for line in lines:
                logger.info(line)
            sys.stdout.flush()
            return report_text


def dump_log_to_gcs(report_text: str, metadata: dict, creds):
    """Uploads the consolidated log report to the GCS bucket in data_profiler_output_logs/ folder."""
    try:
        bucket_name = CONFIG_GCS_URI[5:].split("/", 1)[0]
        
        # Sanitize instance name for filesystem compatibility
        safe_instance = re.sub(r"[^a-zA-Z0-9_-]", "_", metadata["execution_instance"])
        blob_name = f"data_profiler_output_logs/{safe_instance}_{metadata['filename_timestamp']}.log"

        storage_client = storage.Client(credentials=creds)
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(blob_name)

        blob.upload_from_string(report_text, content_type="text/plain")
        logger.info(f"Successfully uploaded final execution log to gs://{bucket_name}/{blob_name}")
    except Exception as e:
        logger.error(f"Failed to upload execution log to GCS: {e}")


def get_impersonated_credentials(target_principal: str):
    """Creates impersonated credentials using default environment credentials."""
    source_credentials, _ = google.auth.default(
        scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )
    return impersonated_credentials.Credentials(
        source_credentials=source_credentials,
        target_principal=target_principal,
        target_scopes=["https://www.googleapis.com/auth/cloud-platform"],
    )


def profile_table_sdk(
    dataplex_client: dataplex_v1.DataScanServiceClient,
    bq_client: bigquery.Client,
    dataplex_project_id: str,
    location: str,
    bq_project_id: str,
    dataset_id: str,
    table_id: str,
    export_results_table: str,
    service_account: str,
    exclude_strings: bool = False,
    sampling_percent: float = None,
    row_filter: str = None,
    additional_excludes: list = None,
):
    """Creates/Updates and triggers a Data Profiling DataScan using official Google Cloud SDK."""
    table_ref_str = f"{bq_project_id}.{dataset_id}.{table_id}"

    # 1. Inspect BigQuery table schema
    table = bq_client.get_table(table_ref_str, timeout=SDK_API_TIMEOUT)

    # 2. Build Column Exclusion List (Handles case-insensitive collation)
    exclude_fields = []
    table_api = table.to_api_repr()
    is_default_ci = table_api.get("defaultCollation") == "und:ci"

    for field in table.schema:
        field_api = field.to_api_repr()
        field_collation = field_api.get("collation")
        if (
            field_collation == "und:ci"
            or (is_default_ci and field.field_type == "STRING")
            or (exclude_strings and field.field_type == "STRING")
        ):
            logger.info(f"Excluding field '{field.name}' from profiling.")
            exclude_fields.append(field.name)

    if additional_excludes:
        for f in additional_excludes:
            if f not in exclude_fields:
                exclude_fields.append(f)

    # 3. Construct DataProfileSpec using SDK Objects
    post_scan_actions = dataplex_v1.DataProfileSpec.PostScanActions(
        bigquery_export=dataplex_v1.DataProfileSpec.PostScanActions.BigQueryExport(
            results_table=export_results_table
        )
    )

    data_profile_spec = dataplex_v1.DataProfileSpec(
        catalog_publishing_enabled=True,
        post_scan_actions=post_scan_actions,
    )

    if sampling_percent is not None and 0.0 < sampling_percent <= 100.0:
        data_profile_spec.sampling_percent = float(sampling_percent)

    if row_filter:
        data_profile_spec.row_filter = row_filter

    if exclude_fields:
        data_profile_spec.exclude_fields = dataplex_v1.DataProfileSpec.SelectedFields(
            field_names=exclude_fields
        )

    # 4. Construct DataScan Payload
    # Generate deterministic hash from the full dataset and table ID
    full_identifier = f"{bq_project_id}.{dataset_id}.{table_id}".encode("utf-8")
    hash_suffix = hashlib.sha256(full_identifier).hexdigest()[:32]

    # Final length: 36 characters (Prefix "dpj-" [4] + Hash [32])
    datascan_id = f"dpj-{hash_suffix}"
    parent = f"projects/{dataplex_project_id}/locations/{location}"
    resource_path = f"//bigquery.googleapis.com/projects/{bq_project_id}/datasets/{dataset_id}/tables/{table_id}"

    data_scan_config = dataplex_v1.DataScan(
        data=dataplex_v1.DataSource(resource=resource_path),
        type_="DATA_PROFILE",
        data_profile_spec=data_profile_spec,
        execution_identity={
            "service_account": {
                "email": service_account
            }
        },  
        execution_spec=dataplex_v1.DataScan.ExecutionSpec(
            trigger=dataplex_v1.Trigger(on_demand=dataplex_v1.Trigger.OnDemand())
        ),
        display_name=f"Profile Scan for {bq_project_id}.{dataset_id}.{table_id}",
    )

    # 5. Create or Update DataScan with strict 60s operation timeout
    try:
        create_req = dataplex_v1.CreateDataScanRequest(
            parent=parent, data_scan=data_scan_config, data_scan_id=datascan_id
        )
        op = dataplex_client.create_data_scan(request=create_req, timeout=SDK_API_TIMEOUT)
        op.result(timeout=60.0)
    except AlreadyExists:
        logger.info(f"DataScan {datascan_id} exists. Updating specification...")
        update_req = dataplex_v1.UpdateDataScanRequest(
            data_scan=dataplex_v1.DataScan(
                name=f"{parent}/dataScans/{datascan_id}",
                data_profile_spec=data_profile_spec,
            ),
            update_mask={"paths": ["data_profile_spec"]},
        )
        op = dataplex_client.update_data_scan(request=update_req, timeout=SDK_API_TIMEOUT)
        op.result(timeout=60.0)

    # 6. Trigger Execution
    datascan_name = f"{parent}/dataScans/{datascan_id}"
    run_job = dataplex_client.run_data_scan(
        request={"name": datascan_name}, timeout=SDK_API_TIMEOUT
    )
    job_name = run_job.job.name

    # 7. Poll Job Until Completion (with Timeout & Exception Shield)
    start_poll_time = time.time()
    poll_count = 0

    while True:
        elapsed = time.time() - start_poll_time
        if elapsed > JOB_TIMEOUT_SECONDS:
            logger.error(
                f"[{table_id}] DataScan timed out after {int(elapsed)} seconds."
            )
            return False, f"Scan timed out after {int(elapsed)}s"

        try:
            job = dataplex_client.get_data_scan_job(
                request={
                    "name": job_name,
                    "view": dataplex_v1.types.GetDataScanJobRequest.DataScanJobView.FULL,
                },
                timeout=SDK_API_TIMEOUT,
            )
            state = job.state

            # Detailed per-table log every 30 seconds (every 3 polls)
            if poll_count % 3 == 0:
                logger.info(
                    f"[{table_id}] Dataplex Backend State: {state.name} (Elapsed: {int(elapsed)}s)"
                )

            if state == dataplex_v1.DataScanJob.State.SUCCEEDED:
                return True, None
            elif state in (
                dataplex_v1.DataScanJob.State.FAILED,
                dataplex_v1.DataScanJob.State.CANCELLED,
            ):
                return False, job.message or f"Ended with state {state.name}"

        except GoogleAPICallError as e:
            logger.warning(
                f"[{table_id}] Transient API error polling job: {e}. Retrying in 10s..."
            )
        except Exception as e:
            logger.warning(
                f"[{table_id}] Unexpected error polling job: {e}. Retrying in 10s..."
            )

        poll_count += 1
        time.sleep(10)


def load_config_from_gcs(gcs_uri: str, creds) -> list:
    """Downloads CSV configuration file from GCS."""
    path_parts = gcs_uri[5:].split("/", 1)
    bucket_name = path_parts[0]
    blob_name = path_parts[1]

    storage_client = storage.Client(credentials=creds)
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(blob_name)

    config_content = blob.download_as_text(encoding="utf-8")
    return list(csv.DictReader(io.StringIO(config_content.strip())))


def process_table_task(
    row: dict,
    creds,
    dataplex_client: dataplex_v1.DataScanServiceClient,
    bq_clients: dict,
    tracker: StatusTracker,
    export_results_table: str,
):
    """Worker function executed per table in thread pool."""
    bq_project_id = row.get("project_id", "").strip()
    dataset_id = row.get("dataset_id", "").strip()
    table_id = (row.get("table_id") or row.get("table") or "").strip()
    location = row.get("location", "us-east4").strip()

    if not bq_project_id or not dataset_id or not table_id:
        return

    table_ref = f"{bq_project_id}.{dataset_id}.{table_id}"
    tracker.update_status(table_ref, status="RUNNING", start_time=time.time())

    exclude_strings_str = row.get("exclude_strings", "false").strip().lower()
    exclude_strings = exclude_strings_str in ("true", "1", "yes")

    sampling_percent_str = (
        row.get("sampling_percent") or row.get("sample_percent") or ""
    ).strip()
    sampling_percent = float(sampling_percent_str) if sampling_percent_str else None

    row_filter = (
        row.get("row_filter") or row.get("condition") or ""
    ).strip() or None

    bq_client = bq_clients[bq_project_id]

    additional_excludes = []
    max_attempts = 2
    success = False
    last_error = None

    for attempt in range(1, max_attempts + 1):
        tracker.update_status(table_ref, attempts=attempt)
        try:
            success, error_msg = profile_table_sdk(
                dataplex_client=dataplex_client,
                bq_client=bq_client,
                dataplex_project_id=DATAPLEX_HOST_PROJECT,
                location=location,
                bq_project_id=bq_project_id,
                dataset_id=dataset_id,
                table_id=table_id,
                export_results_table=export_results_table,
                service_account=DATAPLEX_SERVICE_ACCOUNT,
                exclude_strings=exclude_strings,
                sampling_percent=sampling_percent,
                row_filter=row_filter,
                additional_excludes=additional_excludes,
            )

            if success:
                break

            last_error = error_msg
            if error_msg:
                match = re.search(r"column\(s\) (.*?):", error_msg)
                if match:
                    failed_cols = [
                        c.strip()
                        for c in re.split(r",|-", match.group(1))
                        if c.strip()
                    ]
                    additional_excludes.extend(failed_cols)

        except Exception as e:
            last_error = str(e)

    end_time = time.time()
    if success:
        tracker.update_status(table_ref, status="SUCCEEDED", end_time=end_time)
    else:
        tracker.update_status(
            table_ref,
            status="FAILED",
            end_time=end_time,
            error_message=last_error or "Unknown failure",
        )


def start_status_monitor(tracker: StatusTracker, stop_event: threading.Event):
    """Background daemon thread to periodically output progress metrics using non-blocking wait."""
    start_time = time.time()
    while not stop_event.is_set():
        if stop_event.wait(timeout=STATUS_INTERVAL_SECONDS):
            break

        elapsed = int(time.time() - start_time)
        elapsed_str = f"{elapsed // 60}m {elapsed % 60}s" if elapsed >= 60 else f"{elapsed}s"
        s = tracker.get_summary()
        completed = s["succeeded"] + s["failed"]

        running_tables = tracker.get_running_tables()
        running_info = (
            f"{s['running']} ({', '.join(running_tables)})"
            if running_tables
            else "0"
        )

        logger.info(
            f"[PROGRESS CHECK @ {elapsed_str}] Total: {s['total']} | Completed: {completed}/{s['total']} | "
            f"Running: {running_info} | Succeeded: {s['succeeded']} | Failed: {s['failed']}"
        )
        sys.stdout.flush()


def main():
    metadata = get_execution_metadata()
    creds = get_impersonated_credentials(DATAPLEX_SERVICE_ACCOUNT)

    export_results_table = (
        f"//bigquery.googleapis.com/projects/{EXPORT_PROJECT_ID}"
        f"/datasets/{EXPORT_DATASET_ID}/tables/{EXPORT_TABLE_ID}"
    )

    logger.info(f"Reading CSV config from {CONFIG_GCS_URI}...")
    tasks = load_config_from_gcs(CONFIG_GCS_URI, creds)

    if not tasks:
        logger.error("CSV config file is empty.")
        os._exit(1)

    tracker = StatusTracker()
    valid_tasks = []
    bq_clients = {}

    # Pre-build BigQuery clients cleanly outside worker threads
    for row in tasks:
        bq_project_id = row.get("project_id", "").strip()
        dataset_id = row.get("dataset_id", "").strip()
        table_id = (row.get("table_id") or row.get("table") or "").strip()

        if bq_project_id and dataset_id and table_id:
            table_ref = f"{bq_project_id}.{dataset_id}.{table_id}"
            tracker.register_job(table_ref)
            valid_tasks.append(row)

            if bq_project_id not in bq_clients:
                bq_clients[bq_project_id] = bigquery.Client(
                    credentials=creds, project=bq_project_id
                )
        else:
            logger.warning(f"Skipping malformed row: {row}")

    # Instantiate single Dataplex client to reuse gRPC channels
    dataplex_client = dataplex_v1.DataScanServiceClient(
        credentials=creds, client_options={"quota_project_id": DATAPLEX_HOST_PROJECT}
    )

    logger.info(
        f"Starting parallel execution for {len(valid_tasks)} tables with max workers={MAX_WORKERS}..."
    )

    # Start periodic status logger thread
    stop_monitor_event = threading.Event()
    monitor_thread = threading.Thread(
        target=start_status_monitor, args=(tracker, stop_monitor_event), daemon=True
    )
    monitor_thread.start()

    # Execute tasks in parallel pool
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = [
            executor.submit(
                process_table_task,
                row,
                creds,
                dataplex_client,
                bq_clients,
                tracker,
                export_results_table,
            )
            for row in valid_tasks
        ]
        for _ in as_completed(futures):
            pass  # Wait for all tasks to complete

    logger.info("All parallel worker tasks completed. Stopping status monitor...")

    # Stop background monitoring thread instantly
    stop_monitor_event.set()
    monitor_thread.join(timeout=2)

    # Consolidated Console Summary Output
    report_text = tracker.print_final_report(metadata)

    # Upload execution log to GCS bucket folder: data_profiler_output_logs/
    dump_log_to_gcs(report_text, metadata, creds)

    summary = tracker.get_summary()
    sys.stdout.flush()

    if summary["failed"] > 0:
        logger.error(
            f"Execution completed with {summary['failed']} failed table profilers."
        )
        os._exit(1)
    else:
        logger.info("All table data profiling tasks completed successfully!")
        os._exit(0)


if __name__ == "__main__":
    main()