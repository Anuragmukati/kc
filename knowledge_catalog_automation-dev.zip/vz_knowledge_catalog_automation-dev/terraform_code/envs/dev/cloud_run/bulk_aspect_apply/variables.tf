variable "project_id" {
  type = string
}

variable "region" {
  type    = string
  default = "us-central1"
}

variable "location" {
  type    = string
  default = "us-central1"
}

variable "terraform_sa" {
  type = string
}

variable "image_tag" {
  description = "The commit hash tag for the container image"
  type        = string
  # No default! We want it to fail if Jenkins doesn't pass the hash.
}

variable "aspect_patcher_gcs_bucket" {
  description = "GCS bucket for bulk apply"
  type        = string
  default     = "jyav-dev-dgsdo-0-usre-gkcenrichment"
}

