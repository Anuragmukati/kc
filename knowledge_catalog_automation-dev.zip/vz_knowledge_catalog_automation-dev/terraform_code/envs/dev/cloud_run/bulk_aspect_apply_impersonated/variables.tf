variable "project_id" {
  type = string
}

variable "region" {
  type    = string
  default = "us-east4"
}

variable "location" {
  type    = string
  default = "us-east4"
}

variable "terraform_sa" {
  type = string
}

variable "impersonated_target_sa" {
  type        = string
  default     = ""
  description = "Target service account to impersonate at runtime"
}

variable "image_tag" {
  description = "The commit hash tag for the container image"
  type        = string
}

variable "aspect_patcher_gcs_bucket" {
  description = "GCS bucket for bulk apply"
  type        = string
  default     = "jyav-dev-dgsdo-0-usre-gkcenrichment"
}