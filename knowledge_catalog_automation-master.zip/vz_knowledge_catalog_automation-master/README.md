# Proof of Concept (POC): Google Knowledge Catalog Implementation

## Project Overview
This document outlines the Proof of Concept (POC) for implementing a **Google Knowledge Catalog** (leveraging Google Cloud Data Catalog / Dataplex).

## Directory Structure
```text
📦 vz_knowledge_catalog_automation-master
 ┣ 📂 cloud_run/                        # Application Source Code
 ┃ ┣ 📂 bulk_aspect_apply/             # Bulk aspect tagging engine
 ┃ ┃ ┣ 📜 Dockerfile
 ┃ ┃ ┣ 📜 config.yaml
 ┃ ┃ ┣ 📜 main.py
 ┃ ┃ ┗ 📜 requirements.txt
 ┃ ┣ 📂 data_insights/                 # Data insights generator service
 ┃ ┃ ┣ 📜 Dockerfile
 ┃ ┃ ┣ 📜 config.yaml
 ┃ ┃ ┣ 📜 data_insights.csv
 ┃ ┃ ┣ 📜 main.py
 ┃ ┃ ┗ 📜 requirements.txt
 ┃ ┣ 📂 profiler_cloud_run/            # Data profiling service
 ┃ ┃ ┣ 📜 Dockerfile
 ┃ ┃ ┣ 📜 data_profiler_input.csv
 ┃ ┃ ┣ 📜 profiler_cloud_run.py
 ┃ ┃ ┗ 📜 requirements.txt
 ┃ ┗ 📂 trust_score/                   # Data quality & trust score processing
 ┃   ┣ 📜 Dockerfile
 ┃   ┣ 📜 config.json
 ┃   ┣ 📜 dq_thresholds.json
 ┃   ┣ 📜 main.py
 ┃   ┗ 📜 requirements.txt
 ┃
 ┗ 📂 terraform_code/                  # Infrastructure as Code (GCP Provisioning)
   ┣ 📂 custom_modules/                # Reusable Terraform Modules
   ┃ ┣ 📂 cloudrun_job/                # Module: Cloud Run Job resources
   ┃ ┃ ┣ 📜 main.tf
   ┃ ┃ ┗ 📜 variables.tf
   ┃ ┣ 📂 dataplex_aspect_type/        # Module: Dataplex Aspect Type definitions
   ┃ ┃ ┣ 📜 main.tf
   ┃ ┃ ┣ 📜 outputs.tf
   ┃ ┃ ┗ 📜 variables.tf
   ┃ ┗ 📂 dataplex_datascan/           # Module: Dataplex Data Quality Scans
   ┃   ┗ 📂 data-quality/
   ┃     ┣ 📜 main.tf
   ┃     ┣ 📜 outputs.tf
   ┃     ┗ 📜 variables.tf
   ┗ 📂 envs/                          # Deployment Environments
     ┗ 📂 prod/                        # Production Environment Deployment
       ┣ 📂 cloud_run/                 # Infrastructure deployment per Cloud Run job
       ┃ ┣ 📂 bulk_aspect_apply/       # [main.tf, providers.tf, terraform.tfvars, variables.tf]
       ┃ ┣ 📂 data_insights/           # [main.tf, providers.tf, terraform.tfvars, variables.tf]
       ┃ ┣ 📂 profiler_cloud_run/      # [main.tf, providers.tf, terraform.tfvars, variables.tf]
       ┃ ┗ 📂 trust_score/             # [main.tf, providers.tf, terraform.tfvars, variables.tf]
       ┗ 📂 dataplex/                  # Dataplex rules and DQ deployment
         ┣ 📜 custom_rules.tf
         ┣ 📜 main.tf
         ┣ 📜 prebuilt_rules.tf
         ┣ 📜 profile_based_dq.csv
         ┣ 📜 providers.tf
         ┣ 📜 terraform.tfvars
         ┗ 📜 variables.tf

