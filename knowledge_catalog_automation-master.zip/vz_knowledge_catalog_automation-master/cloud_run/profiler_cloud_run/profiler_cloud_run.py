import csv
import io
import logging
import re
import sys
import time
import hashlib
import google.auth
from google.api_core.exceptions import AlreadyExists, GoogleAPICallError
from google.auth import impersonated_credentials
from google.cloud import bigquery, dataplex_v1, storage


# Configure Logging
logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

# Hardcoded Service Account & Target Project Details
DATAPLEX_SERVICE_ACCOUNT = (
    "sa-pr-jyav-dplex-dgsdo-0@vz-nonit-pr-jyav-dgsdo-0.iam.gserviceaccount.com"
)
DATAPLEX_HOST_PROJECT = "vz-nonit-pr-jyav-dgsdo-0"
EXPORT_PROJECT_ID = "vz-nonit-pr-jyav-dgsdo-0"
EXPORT_DATASET_ID = "gkc_governance_tbls"
EXPORT_TABLE_ID = "all_table_profiles"
CONFIG_GCS_URI = "gs://jyav-prod-dgsdo-0-usre-gkcenrichment/data_profiler_input.csv"



def get_impersonated_credentials(target_principal: str):
    """Creates impersonated credentials using default environment credentials."""
    source_credentials, _ = google.auth.default(
        scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )
    return impersonated_credentials.Credentials(
        source_credentials=source_credentials,
        target_principal=target_principal,
        target_scopes=["https://www.googleapis.com/auth/cloud-platform"],
    )


def profile_table_sdk(
    dataplex_client: dataplex_v1.DataScanServiceClient,
    bq_client: bigquery.Client,
    dataplex_project_id: str,
    location: str,
    bq_project_id: str,
    dataset_id: str,
    table_id: str,
    export_results_table: str,
    service_account: str,
    exclude_strings: bool = False,
    sampling_percent: float = None,
    row_filter: str = None,
    additional_excludes: list = None,
):
    """Creates/Updates and triggers a Data Profiling DataScan using official Google Cloud SDK."""
    table_ref_str = f"{bq_project_id}.{dataset_id}.{table_id}"

    # 1. Inspect BigQuery table schema
    table = bq_client.get_table(table_ref_str)
    # if table.table_type != "TABLE":
    #     logger.warning(
    #         f"Skipping '{table_ref_str}': Data Profiling does not support table type '{table.table_type}'."
    #     )
    #     return

    # 2. Build Column Exclusion List (Handles case-insensitive collation)
    exclude_fields = []
    table_api = table.to_api_repr()
    is_default_ci = table_api.get("defaultCollation") == "und:ci"

    for field in table.schema:
        field_api = field.to_api_repr()
        field_collation = field_api.get("collation")
        if (
            field_collation == "und:ci"
            or (is_default_ci and field.field_type == "STRING")
            or (exclude_strings and field.field_type == "STRING")
        ):
            logger.info(f"Excluding field '{field.name}' from profiling.")
            exclude_fields.append(field.name)

    if additional_excludes:
        for f in additional_excludes:
            if f not in exclude_fields:
                exclude_fields.append(f)

    # 3. Construct DataProfileSpec using SDK Objects
    post_scan_actions = dataplex_v1.DataProfileSpec.PostScanActions(
        bigquery_export=dataplex_v1.DataProfileSpec.PostScanActions.BigQueryExport(
            results_table=export_results_table
        )
    )

    data_profile_spec = dataplex_v1.DataProfileSpec(
        catalog_publishing_enabled=True,
        post_scan_actions=post_scan_actions,
    )

    if sampling_percent is not None and 0.0 < sampling_percent <= 100.0:
        data_profile_spec.sampling_percent = float(sampling_percent)

    if row_filter:
        data_profile_spec.row_filter = row_filter

    if exclude_fields:
        data_profile_spec.exclude_fields = dataplex_v1.DataProfileSpec.SelectedFields(
            field_names=exclude_fields
        )

    # 4. Construct DataScan Payload
    # Generate deterministic hash from the full dataset and table ID
    full_identifier = f"{bq_project_id}.{dataset_id}.{table_id}".encode("utf-8")
    hash_suffix = hashlib.sha256(full_identifier).hexdigest()[:32]

    # Final length: 36 characters (Prefix "dpj-" [4] + Hash [32])
    datascan_id = f"dpj-{hash_suffix}"
    parent = f"projects/{dataplex_project_id}/locations/{location}"
    resource_path = f"//bigquery.googleapis.com/projects/{bq_project_id}/datasets/{dataset_id}/tables/{table_id}"

    data_scan_config = dataplex_v1.DataScan(
        data=dataplex_v1.DataSource(resource=resource_path),
        type_="DATA_PROFILE",
        data_profile_spec=data_profile_spec,
        execution_identity={
            "service_account": {
                "email": service_account
            }
        },  
        execution_spec=dataplex_v1.DataScan.ExecutionSpec(
            trigger=dataplex_v1.Trigger(on_demand=dataplex_v1.Trigger.OnDemand())
        ),
        display_name=f"Profile Scan for {bq_project_id}.{dataset_id}.{table_id}",
    )

    # 5. Create or Update DataScan
    try:
        logger.info(f"Creating DataScan: {datascan_id} in {parent}...")
        create_req = dataplex_v1.CreateDataScanRequest(
            parent=parent, data_scan=data_scan_config, data_scan_id=datascan_id
        )
        op = dataplex_client.create_data_scan(request=create_req)
        op.result()
    except AlreadyExists:
        logger.info(f"DataScan {datascan_id} exists. Updating specification...")
        update_req = dataplex_v1.UpdateDataScanRequest(
            data_scan=dataplex_v1.DataScan(
                name=f"{parent}/dataScans/{datascan_id}",
                data_profile_spec=data_profile_spec,
            ),
            update_mask={"paths": ["data_profile_spec"]},
        )
        op = dataplex_client.update_data_scan(request=update_req)
        op.result()

    # 6. Trigger Execution
    datascan_name = f"{parent}/dataScans/{datascan_id}"
    logger.info(f"Triggering execution of scan: {datascan_id}")
    run_job = dataplex_client.run_data_scan(request={"name": datascan_name})
    job_name = run_job.job.name
    logger.info(f"Job triggered successfully: {job_name}")

    # 7. Poll Job Until Completion
    while True:
        job = dataplex_client.get_data_scan_job(
            request={
                "name": job_name,
                "view": dataplex_v1.types.GetDataScanJobRequest.DataScanJobView.FULL,
            }
        )
        state = job.state
        if state == dataplex_v1.DataScanJob.State.SUCCEEDED:
            logger.info(f"DataScan job '{datascan_id}' succeeded!")
            return True, None
        elif state in (
            dataplex_v1.DataScanJob.State.FAILED,
            dataplex_v1.DataScanJob.State.CANCELLED,
        ):
            logger.error(f"DataScan job failed with state {state}: {job.message}")
            return False, job.message

        logger.info("Scan in progress... sleeping for 10 seconds.")
        time.sleep(10)


def load_config_from_gcs(gcs_uri: str, creds) -> list:
    """Downloads CSV configuration file from GCS."""
    path_parts = gcs_uri[5:].split("/", 1)
    bucket_name = path_parts[0]
    blob_name = path_parts[1]

    storage_client = storage.Client(credentials=creds)
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(blob_name)

    config_content = blob.download_as_text(encoding="utf-8")
    return list(csv.DictReader(io.StringIO(config_content.strip())))


def main():
    creds = get_impersonated_credentials(DATAPLEX_SERVICE_ACCOUNT)

    # Initialize Dataplex client using SDK and Quota Project
    dataplex_client = dataplex_v1.DataScanServiceClient(
        credentials=creds, client_options={"quota_project_id": DATAPLEX_HOST_PROJECT}
    )

    export_results_table = (
        f"//bigquery.googleapis.com/projects/{EXPORT_PROJECT_ID}"
        f"/datasets/{EXPORT_DATASET_ID}/tables/{EXPORT_TABLE_ID}"
    )

    logger.info(f"Reading CSV config from {CONFIG_GCS_URI}...")
    tasks = load_config_from_gcs(CONFIG_GCS_URI, creds)

    if not tasks:
        logger.error("CSV config file is empty.")
        sys.exit(1)

    bq_clients = {}
    has_failed_tables = False

    for row in tasks:
        bq_project_id = row.get("project_id", "").strip()
        dataset_id = row.get("dataset_id", "").strip()
        
        # Robust fallback: handles both 'table' and 'table_id' CSV header names
        table_id = (row.get("table_id") or row.get("table") or "").strip()
        location = row.get("location", "us-east4").strip()

        if not bq_project_id or not dataset_id or not table_id:
            logger.warning(f"Skipping malformed row: missing required fields. {row}")
            continue

        exclude_strings_str = row.get("exclude_strings", "false").strip().lower()
        exclude_strings = exclude_strings_str in ("true", "1", "yes")

        sampling_percent_str = (
            row.get("sampling_percent") or row.get("sample_percent") or ""
        ).strip()
        sampling_percent = (
            float(sampling_percent_str) if sampling_percent_str else None
        )

        row_filter = (
            row.get("row_filter") or row.get("condition") or ""
        ).strip() or None

        if bq_project_id not in bq_clients:
            bq_clients[bq_project_id] = bigquery.Client(
                credentials=creds, project=bq_project_id
            )
        bq_client = bq_clients[bq_project_id]

        logger.info(f"--- Processing Table: {bq_project_id}.{dataset_id}.{table_id} ---")

        # Fallback Retry Loop for failed columns
        additional_excludes = []
        max_attempts = 2
        success = False

        for attempt in range(max_attempts):
            try:
                success, error_msg = profile_table_sdk(
                    dataplex_client=dataplex_client,
                    bq_client=bq_client,
                    dataplex_project_id=DATAPLEX_HOST_PROJECT,
                    location=location,
                    bq_project_id=bq_project_id,
                    dataset_id=dataset_id,
                    table_id=table_id,
                    export_results_table=export_results_table,
                    service_account=DATAPLEX_SERVICE_ACCOUNT,
                    exclude_strings=exclude_strings,
                    sampling_percent=sampling_percent,
                    row_filter=row_filter,
                    additional_excludes=additional_excludes,
                )

                if success:
                    break

                # Self-healing: parse failed column names and exclude on retry
                if error_msg:
                    match = re.search(r"column\(s\) (.*?):", error_msg)
                    if match:
                        failed_cols = [
                            c.strip()
                            for c in re.split(r",|-", match.group(1))
                            if c.strip()
                        ]
                        logger.warning(f"Attempt {attempt + 1}: Excluding failing columns {failed_cols}")
                        additional_excludes.extend(failed_cols)

            except Exception as e:
                logger.error(f"Attempt {attempt + 1} thrown exception: {e}")

        if not success:
            has_failed_tables = True
            logger.error(f"Failed to profile table: {table_id}")

    if has_failed_tables:
        sys.exit(1)
    else:
        logger.info("All table data profiling tasks completed successfully!")
        sys.exit(0)


if __name__ == "__main__":
    main()