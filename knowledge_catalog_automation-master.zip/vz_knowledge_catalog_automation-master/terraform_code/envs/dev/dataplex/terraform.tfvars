project_id             = "vz-nonit-np-jyav-dev-dgsdo-0"
region                 = "us-east4"
location               = "us-east4"
terraform_sa           = "sa-dev-jyav-app-dgsdo-0@vz-nonit-np-jyav-dev-dgsdo-0.iam.gserviceaccount.com"
dataplex_service_agent = "service-594212039830@gcp-sa-dataplex.iam.gserviceaccount.com"
alert_emails           = ["aslahfaseel@verizon.com"]

gcs_bucket_name = "jyav-dev-dgsdo-0-usre-gkcenrichment"
