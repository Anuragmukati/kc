project_id             = "vz-nonit-pr-jyav-dgsdo-0"
region                 = "us-east4"
location               = "us-east4"
terraform_sa           = "sa-pr-jyav-dplex-dgsdo-0@vz-nonit-pr-jyav-dgsdo-0.iam.gserviceaccount.com"
dataplex_service_agent = "service-844814338729@gcp-sa-dataplex.iam.gserviceaccount.com"
alert_emails           = ["aslahfaseel@verizon.com"]

gcs_bucket_name = "jyav-prod-dgsdo-0-usre-gkcenrichment"
