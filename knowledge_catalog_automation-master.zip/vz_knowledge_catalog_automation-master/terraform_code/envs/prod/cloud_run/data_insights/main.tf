module "cloudrun_job" {
  source = "../../../../custom_modules/cloudrun_job"

  project_id            = var.project_id
  location              = var.location
  job_name              = "data-insights"
  
  container_image       = "us-east4-docker.pkg.dev/${var.project_id}/gkc-governance-repo/data_insights:${var.image_tag}"
  
  service_account_email = var.terraform_sa
  vpc_connector         = "projects/vz-it-pr-exhv-sharedvpc-228020/locations/us-east4/connectors/shared-pr-east"
  vpc_egress            = "ALL_TRAFFIC"
  
  max_retries           = 3
  timeout_seconds       = 30600

  kms_key               = "projects/vz-it-pr-d0sv-vsadkms-0/locations/us-east4/keyRings/vz-nonit-pr-kr-vgs/cryptoKeys/vz-nonit-pr-kms-jyav"

  env_vars = {

  }

  labels = {
    purpose = "data-insights"
  }
}