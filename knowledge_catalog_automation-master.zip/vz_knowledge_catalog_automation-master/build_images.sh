#!/bin/bash
alias gcloud='/apps/opt/application/google-cloud-sdk/bin/gcloud'
set -x

WORKSPACE_DIR=$1
BRANCH_NAME=$2
GIT_COMMIT_HASH=$3

# --- AUTHENTICATION PRESTEP ---
set +x 
. ~/.bash_profile
set -x 

export http_proxy=http://proxy.ebiz.verizon.com:80
export https_proxy=http://proxy.ebiz.verizon.com:80

setPRDenv
# ------------------------------

# Resolve environment & upstream fallback based on branch name
if [ "$BRANCH_NAME" = "master" ] || [ "$BRANCH_NAME" = "main" ]; then
    DETECTED_ENV="prod"
    UPSTREAM_DEFAULT="origin/master"
    PROJECT_ID="vz-nonit-pr-jyav-dgsdo-0" # Update project ID if prod/dev use different GCP projects
    BUILD_SA="projects/${PROJECT_ID}/serviceAccounts/sa-pr-jyav-app-dgsdo-0@${PROJECT_ID}.iam.gserviceaccount.com"
else
    DETECTED_ENV="dev"
    UPSTREAM_DEFAULT="origin/dev"
    PROJECT_ID="vz-nonit-np-jyav-dgsdo-0"
    BUILD_SA="projects/${PROJECT_ID}/serviceAccounts/sa-np-jyav-app-dgsdo-0@${PROJECT_ID}.iam.gserviceaccount.com"
fi

AR_REGION="us-east4"
REPO_NAME="gkc-governance-repo"
BASE_IMAGE_URI="${AR_REGION}-docker.pkg.dev/${PROJECT_ID}/${REPO_NAME}"

echo "Detecting changes in cloud_run directories for environment: ${DETECTED_ENV}..."
cd ${WORKSPACE_DIR}

git fetch --depth=5 2>/dev/null
DIFF_FILES=$(git diff --name-only HEAD~1 HEAD 2>/dev/null)

if [ $? -ne 0 ] || [ -z "$DIFF_FILES" ]; then
    echo "First run on a new branch detected. Checking changes against remote origin..."
    UPSTREAM_BRANCH=$(git rev-parse --abbrev-ref --symbolic-full-name @{u} 2>/dev/null || echo "${UPSTREAM_DEFAULT}")
    git fetch origin $(echo $UPSTREAM_BRANCH | cut -d/ -f2) --depth=5 2>/dev/null
    DIFF_FILES=$(git diff --name-only $UPSTREAM_BRANCH HEAD 2>/dev/null)
fi

APPS_CHANGED=$(echo "$DIFF_FILES" | grep "^cloud_run/" | cut -d/ -f2 | sort | uniq)
TF_CHANGED=$(echo "$DIFF_FILES" | grep "^terraform_code/envs/${DETECTED_ENV}/cloud_run/" | cut -d/ -f5 | sort | uniq)

SHARED_CR_CHANGED=$(echo "$DIFF_FILES" | grep "^terraform_code/custom_modules/cloudrun_job/")
if [ ! -z "$SHARED_CR_CHANGED" ]; then
    echo "Shared Cloud Run module updated. Triggering catch-all rebuild."
    TF_CHANGED=$(ls -1 ${WORKSPACE_DIR}/cloud_run/ 2>/dev/null)
fi

CHANGED_FOLDERS=$(echo -e "$APPS_CHANGED\n$TF_CHANGED" | sed '/^$/d' | sort | uniq)

if [ -z "$CHANGED_FOLDERS" ]; then
    echo "No cloud_run applications modified in this commit. Skipping builds."
else
    for APP_NAME in $CHANGED_FOLDERS; do
        APP_DIR="${WORKSPACE_DIR}/cloud_run/${APP_NAME}"
        IMAGE_NAME_LOWER=$(echo "$APP_NAME" | tr '[:upper:]' '[:lower:]')
        
        if [ -d "$APP_DIR" ]; then
            echo "Building image for: ${APP_NAME} using format target: ${IMAGE_NAME_LOWER} with commit hash: ${GIT_COMMIT_HASH}"
            
            TARGET_COMPLIANT_BUCKET="gs://${PROJECT_ID}_cloudbuild"

            gcloud builds submit "${APP_DIR}" \
                --tag="${BASE_IMAGE_URI}/${IMAGE_NAME_LOWER}:${GIT_COMMIT_HASH}" \
                --project="${PROJECT_ID}" \
                --region="${AR_REGION}" \
                --service-account="${BUILD_SA}" \
                --gcs-source-staging-dir="${TARGET_COMPLIANT_BUCKET}/source" \
                --gcs-log-dir="${TARGET_COMPLIANT_BUCKET}/logs"
                
            if [[ $? -ne 0 ]]; then 
                echo "Failed to build image for ${APP_NAME}"
                exit 1
            fi
        fi
    done
    echo "All applicable images built and pushed successfully!"
fi